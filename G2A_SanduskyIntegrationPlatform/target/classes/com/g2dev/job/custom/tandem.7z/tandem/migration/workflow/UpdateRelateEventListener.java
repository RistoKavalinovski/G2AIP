package com.g2dev.job.custom.tandem.migration.workflow;

public interface UpdateRelateEventListener {

	void updateEvent();

}
