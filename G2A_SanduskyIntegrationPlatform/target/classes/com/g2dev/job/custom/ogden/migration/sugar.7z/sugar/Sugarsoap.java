/**
 * Sugarsoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.g2dev.job.custom.ogden.migration.sugar;

public interface Sugarsoap extends javax.xml.rpc.Service {
    public java.lang.String getsugarsoapPortAddress();

    public com.g2dev.job.custom.ogden.migration.sugar.SugarsoapPortType getsugarsoapPort() throws javax.xml.rpc.ServiceException;

    public com.g2dev.job.custom.ogden.migration.sugar.SugarsoapPortType getsugarsoapPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
